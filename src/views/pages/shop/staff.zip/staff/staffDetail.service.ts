import { Injectable, ServiceRoute, RouteGuard } from 'vue-service-app'
import { StaffApi } from '@/api/staff/staff'
// import { State, Computed, Effect, Action } from 'rx-state'
// import { pluck } from 'rxjs/operators'
// import { Store } from '@/services/store'

// interface StaffState {
//   name: string
//   age: number
// }
// @Injectable()
export class StaffService {}

//   beforeRouteEach(to: ServiceRoute, from: ServiceRoute, next: any) {
//     next()
//   }
